package com.capgemini.bankwallet.exception;

public class InvalidInputException {

}
